<?php

$functions = array(
    'mod_resource_get_info' => array(
        'classname'   => 'mod_resource_external',
        'methodname'  => 'get_files_info',
        'classpath'   => 'mod/resource/externallib.php',
        'description' => 'Get resources files info',
        'type'        => 'read',
    )
);