<?php
require_once("$CFG->libdir/externallib.php");

/**
 * Resource external file
 *
 * @package    mod_resource
 * @copyright  2012 Bruno Sampaio
 */
class mod_resource_external extends external_api {
 
    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_files_info_parameters() {
        return new external_function_parameters(
            array('ids' => new external_multiple_structure(new external_value(PARAM_INT, 'activities ids')))
        );
    }


	/**
     * Returns description of method return parameters
     * @return external_function_return_parameters
     */
	public static function get_files_info_returns() {
		return new external_multiple_structure(
			new external_single_structure(
				array(
					'id' => new external_value(PARAM_INT, 'activity id'),
					'name' => new external_value(PARAM_TEXT, 'activity name'),
					'description' => new external_value(PARAM_RAW, 'activity description'),
					'type' => new external_value(PARAM_TEXT, 'resource type'),
					'file' => new external_value(PARAM_TEXT, 'resource file name'),
					'path' => new external_value(PARAM_TEXT, 'resource file path'),
					'size' => new external_value(PARAM_INT, 'resource file size'),
					'url' => new external_value(PARAM_TEXT, 'resource file url'),
					'created' => new external_value(PARAM_INT, 'creation date'),
					'modified' => new external_value(PARAM_INT, 'last modification date')
				),
				'resource data'
			)
		);
	}
	
	
	/**
     * Get resources files info
     * @param array $ids - the activities ids
     * @return array of resources
     */
    public static function get_files_info($ids) {
        global $CFG, $DB;
		require_once($CFG->dirroot . '/mod/resource/lib.php');

        $params = self::validate_parameters(self::get_files_info_parameters(), array('ids' => $ids));

		$sql = 
			"SELECT {course_modules}.id, {course_modules}.module, {course_modules}.instance,
				{resource}.name, {resource}.intro as description
			FROM {course_modules} INNER JOIN {resource} ON ({resource}.id = {course_modules}.instance)
			WHERE {course_modules}.id IN (:ids) AND {course_modules}.module = 14";
			
		$data = $DB->get_records_sql($sql, array('ids' => implode(', ', $ids)));
		
		$resources = array();
		foreach($data as $module) {
			$files = resource_export_contents($module, 'webservice/pluginfile.php');
			
			if(count($files) > 0) {
				$resource = array(
					'id' => $module->id,
					'name' => $module->name, 
					'description' => $module->description,
					'type' => $files[0]['type'],
					'file' => $files[0]['filename'],
					'path' => $files[0]['filepath'],
					'size' => $files[0]['filesize'],
					'url' => $files[0]['fileurl'],
					'created' => $files[0]['timecreated'],
					'modified' => $files[0]['timemodified']
				);
				array_push($resources, $resource);
			}
		}

        return $resources;
    }
}