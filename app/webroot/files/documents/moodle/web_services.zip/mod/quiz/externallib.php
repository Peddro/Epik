<?php
require_once("$CFG->libdir/externallib.php");

/**
 * Quiz external file
 *
 * @package    mod_quiz
 * @copyright  2012 Bruno Sampaio
 */
class mod_quiz_external extends external_api {
 
    /**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_questions_info_parameters() {
        return new external_function_parameters(
            array('activityid' => new external_value(PARAM_INT, 'activity id'))
        );
    }


	/**
     * Returns description of method parameters
     * @return external_function_parameters
     */
    public static function get_questions_data_parameters() {
        return new external_function_parameters(
            array('ids' => new external_multiple_structure(new external_value(PARAM_INT, 'questions ids')))
        );
    }


	/**
     * Returns description of method return parameters
     * @return external_function_return_parameters
     */
	public static function get_questions_info_returns() {
		return new external_multiple_structure(
			new external_single_structure(
				array(
					'id' => new external_value(PARAM_INT, 'question id'),
					'name' => new external_value(PARAM_TEXT, 'question name'),
					'content' => new external_value(PARAM_RAW, 'question text'),
					'type' => new external_value(PARAM_TEXT, 'question type')
				),
				'question data'
			)
		);
	}
	
	
	/**
     * Returns description of method return parameters
     * @return external_function_return_parameters
     */
	public static function get_questions_data_returns() {
		return new external_multiple_structure(
			new external_single_structure(
				array(
					'id' => new external_value(PARAM_INT, 'question id'),
					'name' => new external_value(PARAM_TEXT, 'question name'),
					'content' => new external_value(PARAM_RAW, 'question text'),
					'type' => new external_value(PARAM_TEXT, 'question type'),
					'created' => new external_value(PARAM_INT, 'creation date'),
					'modified' => new external_value(PARAM_INT, 'last modification date'),
					'answers' => new external_multiple_structure(
						new external_single_structure(
							array(
								'content' => new external_value(PARAM_RAW, 'answer text'),
								'fraction' => new external_value(PARAM_FLOAT, 'answer fraction')
							)
						),
						'question answers list',
						VALUE_OPTIONAL
					),
					'hints' => new external_multiple_structure(
						new external_single_structure(
							array(
								'content' => new external_value(PARAM_RAW, 'hint text')
							)
						),
						'question hints list',
						VALUE_OPTIONAL
					)
				),
				'question data'
			)
		);
	}
	
	
	/**
     * Get quiz questions info
     * @param array $activityid - the id of this activity
     * @return array of questions
     */
    public static function get_questions_info($activityid) {
        global $CFG, $DB;

        $params = self::validate_parameters(self::get_questions_info_parameters(), array('activityid' => $activityid));

		$sql = 
			"SELECT {question}.id, {question}.name, {question}.questiontext as content, {question}.qtype as type
			FROM {course_modules} 
				INNER JOIN {quiz_question_instances} ON ({course_modules}.instance = {quiz_question_instances}.quiz)
				INNER JOIN {question} ON ({question}.id = {quiz_question_instances}.question)
			WHERE {course_modules}.id = :activityid";
		
		$data = $DB->get_records_sql($sql, array('activityid' => $params['activityid']));
		
		$questions = array();
		foreach($data as $question) {
			array_push($questions, array('id' => $question->id, 'name' => $question->name, 'content' => $question->content, 'type' => $question->type));
		}

        return $questions;
    }


	/**
     * Get quiz questions data
     * @param array $ids - the questions ids
     * @return array of questions and their respective answers and hints
     */
    public static function get_questions_data($ids) {
		global $CFG, $DB;

        $params = self::validate_parameters(self::get_questions_data_parameters(), array('ids' => $ids));

		$sql = 
			"SELECT {question}.id, {question}.name, {question}.questiontext as question, {question}.qtype as type, 
				{question}.timecreated as created, {question}.timemodified as modified,
				{question_answers}.id as answerid, {question_answers}.answer, {question_answers}.fraction,
				{question_hints}.id as hintid, {question_hints}.hint
			FROM {question} 
				LEFT JOIN {question_answers} ON ({question_answers}.question = {question}.id)
				LEFT JOIN {question_hints} ON ({question_hints}.questionid = {question}.id)
			WHERE {question}.id IN (:ids)
			ORDER BY {question}.id";

		$data = $DB->get_recordset_sql($sql, array('ids' => implode(', ', $ids)));
		
		$questions = array();
		$current_id = null;
		$item = array();
		foreach($data as $question) {
			if($current_id != $question->id) {
				if($current_id) {
					array_push($questions, $item);
					$item = array();
				}
				$current_id = $question->id;
				$item['id'] = $question->id;
				$item['name'] = $question->name;
				$item['content'] = $question->question;
				$item['type'] = $question->type;
				$item['created'] = $question->created;
				$item['modified'] = $question->modified;
			}
			
			if(isset($question->answerid) && $question->answerid) {
				$answer = array('content' => $question->answer, 'fraction' => $question->fraction);
				if(!isset($item['answers'])) {
					$item['answers'] = array();
				}
				$item['answers'][$question->answerid] = $answer;
			}
			
			if(isset($question->hintid) && $question->hintid) {
				$hint = array('content' => $question->hint);
				if(!isset($item['hints'])) {
					$item['hints'] = array();
				}
				$item['hints'][$question->hintid] = $hint;
			}
		}
		array_push($questions, $item);
		
		
		return $questions;
	}
}