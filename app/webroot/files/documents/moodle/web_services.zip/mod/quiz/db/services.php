<?php

$functions = array(
    'mod_quiz_get_questions_info' => array(
        'classname'   => 'mod_quiz_external',
        'methodname'  => 'get_questions_info',
        'classpath'   => 'mod/quiz/externallib.php',
        'description' => 'Get quiz questions info',
        'type'        => 'read',
    ),
	'mod_quiz_get_questions_data' => array(
        'classname'   => 'mod_quiz_external',
        'methodname'  => 'get_questions_data',
        'classpath'   => 'mod/quiz/externallib.php',
        'description' => 'Get quiz questions data including answers and hints',
        'type'        => 'read',
    )
);